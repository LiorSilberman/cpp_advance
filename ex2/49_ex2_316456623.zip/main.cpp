#include "ShippingNetwork.h"

int main(int argc,char** argv) {
    ShippingNetwork x(argc,argv);
    return 0;
}